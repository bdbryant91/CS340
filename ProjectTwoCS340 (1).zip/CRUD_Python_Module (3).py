# AUTHOR: Breanna Bryant
# DATE:   04/19/2026
# COURSE: CS 340  Client/Server Development

from pymongo import MongoClient
from bson.objectid import ObjectId


class AnimalShelter(object):

    def __init__(self, username: str, password: str, host: str = "localhost", port: int = 27017,
                 db_name: str = "aac", collection_name: str = "animals", auth_source: str = "admin"):
        uri = f"mongodb://{username}:{password}@{host}:{port}/{db_name}?authSource={auth_source}"
        self.client = MongoClient(uri)
        self.database = self.client[db_name]
        self.collection = self.database[collection_name]

    #Create
    def create(self, data: dict) -> bool:
        if not data or not isinstance(data, dict):
            raise Exception("Nothing to save, data parameter is empty or invalid")
        result = self.collection.insert_one(data)
        return bool(result.inserted_id)

    #Read
    def read(self, query: dict, projection: dict | None = None) -> list[dict]:
        if query is None:
            raise Exception("Nothing to search, query parameter is empty")
        cursor = self.collection.find(query, projection)
        return list(cursor)

    #Update
    def update(self, query: dict, update_data: dict) -> int:
        if not query or not update_data:
            raise Exception("Query or update data parameter is empty")
        result = self.collection.update_many(query, {"$set": update_data})
        return result.modified_count

    #Delete
    def delete(self, query: dict) -> int:
        if not query:
            raise Exception("Nothing to delete, query parameter is empty")
        result = self.collection.delete_many(query)
        return result.deleted_count